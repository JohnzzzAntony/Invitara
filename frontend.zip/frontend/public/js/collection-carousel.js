/* Homepage carousel; catalogue browsing remains a grid. */
(function(){
 'use strict';
 if(document.body.dataset.page!=='home')return;
 var track=document.getElementById('collection-grid');if(!track)return;
 var reduced=matchMedia('(prefers-reduced-motion: reduce)'),paused=reduced.matches,hover=false,visible=false,timer;
 track.classList.add('collection-carousel');track.setAttribute('role','region');track.setAttribute('aria-roledescription','carousel');track.setAttribute('aria-label','Invitation templates');
 var controls=document.createElement('div');controls.className='carousel-controls';controls.innerHTML='<button type="button" aria-label="Previous templates" aria-controls="collection-grid">←</button><span class="carousel-position"></span><button type="button" aria-label="Next templates" aria-controls="collection-grid">→</button><button type="button" class="carousel-pause" aria-pressed="false">Pause slideshow</button>';track.before(controls);
 var previous=controls.children[0],position=controls.children[1],next=controls.children[2],toggle=controls.children[3];
 function canMove(){return track.scrollWidth>track.clientWidth+4;}
 function sync(){clearTimeout(timer);if(!paused&&!hover&&visible&&!document.hidden&&!track.contains(document.activeElement)&&canMove())timer=setTimeout(function(){move(1);sync();},4500);}
 function move(direction){var cards=track.children;if(!cards.length)return;var step=cards[0].getBoundingClientRect().width+parseFloat(getComputedStyle(track).columnGap||0),max=track.scrollWidth-track.clientWidth,target=track.scrollLeft+step*direction;if(direction>0&&track.scrollLeft>=max-4)target=0;if(direction<0&&track.scrollLeft<=4)target=max;track.scrollTo({left:Math.max(0,Math.min(max,target)),behavior:reduced.matches?'instant':'smooth'});}
 function status(){var cards=track.children,step=cards.length?cards[0].getBoundingClientRect().width+parseFloat(getComputedStyle(track).columnGap||0):1;position.textContent=cards.length?(Math.round(track.scrollLeft/step)+1)+' / '+cards.length:'';previous.disabled=next.disabled=!canMove();controls.hidden=!cards.length;toggle.hidden=!canMove();}
 function pauseLabel(){toggle.textContent=paused?'Play slideshow':'Pause slideshow';toggle.setAttribute('aria-pressed',String(paused));}
 previous.onclick=function(){move(-1);sync();};next.onclick=function(){move(1);sync();};toggle.onclick=function(){paused=!paused;pauseLabel();sync();};
 track.addEventListener('pointerenter',function(e){if(e.pointerType==='mouse'){hover=true;sync();}});track.addEventListener('pointerleave',function(){hover=false;sync();});
 track.addEventListener('pointerdown',function(){clearTimeout(timer);});track.addEventListener('pointerup',sync);track.addEventListener('pointercancel',sync);
 track.addEventListener('focusin',sync);track.addEventListener('focusout',function(){setTimeout(sync,0);});track.addEventListener('scroll',status,{passive:true});
 document.addEventListener('visibilitychange',sync);reduced.addEventListener('change',function(){paused=reduced.matches;pauseLabel();sync();});
 new IntersectionObserver(function(entries){visible=entries[0].isIntersecting;sync();},{threshold:.15}).observe(track);
 new ResizeObserver(function(){status();sync();}).observe(track);
 new MutationObserver(function(){track.scrollTo({left:0,behavior:'instant'});status();sync();}).observe(track,{childList:true});
 pauseLabel();status();sync();
})();
